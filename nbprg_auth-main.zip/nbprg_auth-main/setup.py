from setuptools import setup

setup(
    name="nbprg_auth",
    version="0.0.1",
    packages=["nbprg_auth"],
    description="",
    author="Saifur Rahman",
    author_email="novbh091@gmail.com",
    license="MIT",
    install_requires=[
        "requests"
    ],
)